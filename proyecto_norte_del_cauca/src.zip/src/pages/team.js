import React from 'react';

const Team = () => {
  return (
    <div className='home'>
      <h1>equipo</h1>
    </div>
  );
};

export default Team;
