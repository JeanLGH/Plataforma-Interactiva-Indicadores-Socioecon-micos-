import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import * as topojson from 'topojson-client';

function CaucaMap({ dataAsMap, options }) {
  
  return ;
}

export default CaucaMap;
